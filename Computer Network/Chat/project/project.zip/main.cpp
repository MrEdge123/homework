#include "loginwindow.h"
#include "chatwindow.h"
#include "listwindow.h"
#include "user.h"
#include <QApplication>
#include <QNetworkInterface>
#include <QHostInfo>
#include <QFile>

int main(int argc, char *argv[])
{
    /*
    if(QT_VERSION>=QT_VERSION_CHECK(5,6,0))
            QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
            */

    QApplication a(argc, argv);
    LoginWindow w1;
    w1.show();

    return a.exec();
}
